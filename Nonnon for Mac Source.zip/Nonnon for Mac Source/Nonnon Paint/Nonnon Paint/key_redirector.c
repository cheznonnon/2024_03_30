// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




@interface NonnonPaintKeyRedirector : NSView

@property (nonatomic,assign) id delegate;

@end


@implementation NonnonPaintKeyRedirector


@synthesize delegate;


- init
{
	self = [super init];
	if ( self )
	{
		//
	}

	return self;
}




- (BOOL)acceptsFirstResponder
{
//NSLog(@"acceptsFirstResponder");
	return YES;
}

- (BOOL)becomeFirstResponder
{
//NSLog(@"becomeFirstResponder");
        return YES;
}

- (void) keyDown:(NSEvent *)theEvent
{
//NSLog(@"keyDown");

	// [Needed] : NSTrackingMouseEnteredAndExited

	[self.delegate keyDown:theEvent];

}




@end


